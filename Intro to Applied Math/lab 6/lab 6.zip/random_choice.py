from random import randint

def play(n,hist,lw,lc,y):

    # Return a random number between 0 and 11
    return randint(0,11)
