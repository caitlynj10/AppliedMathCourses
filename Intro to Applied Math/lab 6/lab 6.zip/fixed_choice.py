def play(n,hist,lw,lc,y):

    # Just always return 2
    return 2
