from random import randint

def play(n,hist,lw,lc,y):

    # Choose the previous winning entry plus or minus 1
    return lw+randint(-1,1)
