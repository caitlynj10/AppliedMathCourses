with open("brandeisbabson(1).txt", 'r') as file:
    content = file.read()
    print(content)
    

